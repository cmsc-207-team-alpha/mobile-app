
var config = {
    apiUrl: "https://cmsc-207-team-alpha.000webhostapp.com/api/"
};