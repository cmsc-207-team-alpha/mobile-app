var sms = {
    initiateMessage: function(mobilenum) {
        
    }
};