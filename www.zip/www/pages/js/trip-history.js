var triphis = {
	initialize: function() {
        triphis.id = decodeURIComponent(window.location.search.match(/(\?|&)id\=([^&]*)/)[2]);
        triphis.bindEvents();
    },
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    onDeviceReady: function() {
        triphis.getHistory();
    },
    getHistory: function(){
    	var list = document.getElementById('list');
    	list.setAttribute('style', "visibility: visible;");    	

        $.ajax({
            type: "GET",
            url: config.apiUrl + "trip/gethistory.php",
            data: {
                passengerid: triphis.id
            },
            success: function (result) {
            	$.each(result, function (index, element) {
            		if(result[index]['stage'] === 'Completed')
            		{
	                var datecreated = result[index]['datecreated'];

	                var dateObject = new Date(datecreated);
				    var day = dateObject.getDate();
				    var month = dateObject.getMonth() + 1;
				    var year = dateObject.getFullYear();
				    day = day < 10 ? "0" + day : day; 
				    month = month < 10 ? "0" + month : month; 
				    var formattedDate = day + "/" + month + "/" + year;    

	               	var onsItem = document.createElement('ons-list-item');

			        var centerDiv = document.createElement('div');
			        centerDiv.setAttribute('class', "center");
			        centerDiv.innerHTML = formattedDate + '<br/>' +
			        					'Source: ' + result[index]['source'] + '<br/>' +
			        					'Destination: ' + result[index]['destination'] + '<br/><br/>' +
			        					'Driver: ' + result[index]['driverfirstname'] + ' ' + result[index]['driverlastname'];

			        onsItem.appendChild(centerDiv);
			      
			        list.appendChild(onsItem);
			    	}
		    	});
            },
            error: function (error) {
                console.log(error);
            },
            contentType: "text/plain",
            dataType: "json"
        });
    },

    back: function(){
        window.location.href = "ride-request.html";  
    }
};
