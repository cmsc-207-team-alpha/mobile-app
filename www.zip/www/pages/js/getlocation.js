var worker = new Worker("pages/js/worker.js");
worker.onmessage = function(event) {  
	if(pendingride.vehicleid != 0)
	{
    $.ajax({
        type: "GET",
        url: config.apiUrl + "vehicle/get.php",
        data: {
            id: pendingride.vehicleid
        },
        success: function (result) {     
            var pos = {
	            lat: result['locationlat'],
	            lng: result['locationlong']
	        };
            map.plotLocation(pos);
        },
        error: function(error){
        },
        contentType: "application/json; charset=utf-8",
        dataType: "json"
        });   
	}
};